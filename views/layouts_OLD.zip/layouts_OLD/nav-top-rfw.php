<nav class="header-nav">
	<div class="container navbar hidden-xs">
		<div class="row">
			<div class="col-md-12 col-sm-12 full-height">
				<div class="logo center-block"></div>
			</div>
		</div>
	</div>

	<div class="noexam-logo center-block hidden-xs"></div>

	<div class="navbar-mobile hidden visible-xs">
		<div class="head">
			<div class="button"></div>
			<div class="logo"></div>
			<a href="#" class="q-mark" data-toggle="tooltip" data-placement="left" title="Please enter the information for the person who is applying for life insurance."></a>
		</div>
	</div>
</nav>
